//Assignment No:	Lab 3
//Student Name:		Rasul Iskandarov
//Student Number:	C00246498
//Date:				24/11/2021

#include "lab3.h"
int main()
{

	int array[4][6] = {   {0, 0, 1, 5, 5, 5},
						  {0, 0, 1, 5, 5, 2},
						  {0, 0, 1, 1, 1, 2},
						  {0, 0, 1, 1, 3, 2} };

	char code[1000] = "int main() \n{ \n  intNotint int var1=10;\n char var2 =10;\n if(var1<10) \n {\n int var3=20;\n} char var222;\n}\n";
	char codeInScope[1000] = "int main() \n{ \n int numElephants=10;\n int var2 =10; \n intNotint if(var2<10) \n {\n int var3=20;\n}\nwhile (var2 <0) \n {\n int var4; \n} \n int var5 =10;\n ";
	char variables[1000] = "";
	char variablesInScope[1000] = "";

	PrintArray(array);

	int score = ReplaceWithMinusOne(array);
	std::cout << "The score is: " << score << std::endl << std::endl;


	PrintArray(array);

	FallDownAndReplace(array);

	PrintArray(array);


	std::cout << code << std::endl << std::endl;
	FindAllVariables(variables, code);
	std::cout << "VARIABLES:" << variables << std::endl;

	std::cout << codeInScope << std::endl << std::endl;
	FindAllVariablesInScope(variablesInScope, codeInScope, 8);
	std::cout << "VARIABLES IN SCOPE:" << variablesInScope << std::endl;


}